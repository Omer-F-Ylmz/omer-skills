---
name: frontend-craft
description: "1 skill'lik paket (Frontend UI tasarım ve uygulama: yön keşfi, DESIGN.md, slop denetimi, vitrin teknikleri). İlgili alt skill'in dosyasını oku ve uygula."
---

# frontend-craft

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| frontend-craft | Web arayüzü (landing, vitrin, panel) tasarım-uygulama disiplini — marka kararı, referans eşleme, 3 genişlikte screenshot, yasak liste, a11y/perf kabulü. HTML/CS | `skills/frontend-craft/TALIMAT.md` |
