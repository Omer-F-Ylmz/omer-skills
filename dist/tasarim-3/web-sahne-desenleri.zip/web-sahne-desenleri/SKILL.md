---
name: web-sahne-desenleri
description: "1 skill'lik paket (Premium landing/portfolyo sahne desenleri ve kalite kapısı). İlgili alt skill'in dosyasını oku ve uygula."
---

# web-sahne-desenleri

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| web-sahne-desenleri | Premium landing, portfolyo ve 3D hero isinde ac: WebGL imlec reveal, scroll'a bagli 3D urun pozu, helezon galeri, editoryal tipografi ve sahne kalite kapisi. Yi | `skills/web-sahne-desenleri/TALIMAT.md` |
