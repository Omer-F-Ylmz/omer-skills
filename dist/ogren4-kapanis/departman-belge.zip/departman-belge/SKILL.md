---
name: departman-belge
description: "1 skill'lik paket (Belge muduru). İlgili alt skill'in dosyasını oku ve uygula."
---

# departman-belge

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| departman-belge | Belge müdürü: docx/pptx/pdf/xlsx, rapor ve doküman üretim sırası. Sunum, PDF, proje dokümantasyonu ya da metin düzeltme işinde oku. | `skills/departman-belge/TALIMAT.md` |
