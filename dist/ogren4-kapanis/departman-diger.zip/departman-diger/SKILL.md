---
name: departman-diger
description: "1 skill'lik paket (Departmansiz isler muduru (video hatti dahil)). İlgili alt skill'in dosyasını oku ve uygula."
---

# departman-diger

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| departman-diger | Departmansız işler müdürü: video kurgu, Blender/3D, oyun/mod, görsel üretim, otomasyon/kazıma, hukuk, pazarlama, bulut/k8s, ML/eval, mobil, dil uzmanlığı. Bu iş | `skills/departman-diger/TALIMAT.md` |
