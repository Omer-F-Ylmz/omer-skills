---
name: opus-akis
description: "1 skill'lik paket (Haiku/Sonnet iş yürütme akışı çekirdeği). İlgili alt skill'in dosyasını oku ve uygula."
---

# opus-akis

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| opus-akis | Haiku/Sonnet/ücretsiz modelde iş yürütme akışı (Opus oturumlarından kanıtlı kalıp) — sınıfla, envanter, küçük doğrulanabilir adım, kanıt, hata sonrası, DUR. Kod | `skills/opus-akis/TALIMAT.md` |
