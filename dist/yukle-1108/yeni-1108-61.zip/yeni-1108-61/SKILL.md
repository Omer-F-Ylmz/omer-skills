---
name: yeni-1108-61
description: "15 skill'lik paket (sira4 kurulum 8 Kas). İlgili alt skill'in dosyasını oku ve uygula."
---

# yeni-1108-61

Bu paket 15 skill'i tek girişte toplar. Kullanım: aşağıdan işe uyan alt skill'i seç, `TALIMAT.md` dosyasını oku ve uygula; gerekirse aynı klasördeki REFERANS/KAYNAK dosyalarına bak.

> Not: claude.ai paket başına tek SKILL.md ve en çok 200 dosya kabul ediyor. Bu yüzden her alt skill en çok üç tür dosyaya sıkıştırıldı: `TALIMAT.md` (orijinal SKILL.md), `REFERANS.md` (tüm ek .md dosyaları `## [yol]` başlıklarıyla) ve `KAYNAK-n.md` (betik, json, css gibi diğer metin dosyaları `### yol` başlığı + kod bloğu olarak). Bir dosya gerekirse ilgili başlıktan aynen çıkarılıp yazılabilir. Resim/font gibi ikili (ya da 1 MB üstü) dosyalar alınmadı; listesi REFERANS.md sonunda, asılları Claude Code kurulumunda duruyor.

| skill | ne zaman | dosya |
|---|---|---|
| MeiGen | Compose MeiGen image/video and five dedicated image tools inside an existing workflow, or opt into creative planning. Preserves caller prompts, parameters, appr | `skills/meigen/TALIMAT.md` |
| MeiGen Visual Creative Expert | >- | `skills/meigen-visual-creative-expert/TALIMAT.md` |
| Product Photoshoot Workflow | >- | `skills/product-photoshoot-workflow/TALIMAT.md` |
| Social Thumbnail Workflow | >- | `skills/social-thumbnail-workflow/TALIMAT.md` |
| clawhub | Search and install agent skills from ClawHub, the public skill registry. | `skills/clawhub/TALIMAT.md` |
| cron | Schedule reminders and recurring tasks. | `skills/hkuds-cron/TALIMAT.md` |
| github | Manage GitHub issues and pull requests, inspect CI runs, and query repository data. | `skills/hkuds-github/TALIMAT.md` |
| image-generation | Generate images and iteratively edit saved image artifacts. | `skills/hkuds-image-generation/TALIMAT.md` |
| memory | Search past conversations in the agent's history log. | `skills/memory/TALIMAT.md` |
| my | Inspect or troubleshoot the agent's runtime state, adjust runtime settings, or keep temporary session notes. | `skills/my/TALIMAT.md` |
| nanobot-document | Answer nanobot usage, configuration, and troubleshooting questions from its bundled documentation. | `skills/nanobot-document/TALIMAT.md` |
| skill-creator | Create, update, or package agent skills. | `skills/hkuds-skill-creator/TALIMAT.md` |
| summarize | Summarize or extract text and transcripts from URLs, YouTube videos, podcasts, and local files. | `skills/summarize/TALIMAT.md` |
| tmux | Use when a CLI task needs an interactive terminal or control of a tmux session. | `skills/tmux/TALIMAT.md` |
| weather | Get current weather and forecasts. | `skills/weather/TALIMAT.md` |
