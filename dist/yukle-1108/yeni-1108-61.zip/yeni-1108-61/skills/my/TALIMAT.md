---
name: my
description: Inspect or troubleshoot the agent's runtime state, adjust runtime settings, or keep temporary session notes.
---

> Paket notu: bu skill'in ek dosyaları aynı klasörde `REFERANS.md` (ek .md'ler) ve `KAYNAK-n.md` (diğer metin dosyaları) içinde yol başlıklarıyla duruyor. Metinde bir dosya yolu geçince o başlığı ara.

# Self-Awareness

## How to use

1. **Identify the situation** from the categories below
2. **Call the my tool** with the appropriate action
3. **If set**, warn the user before changing impactful settings such as the model or runtime limits
4. **For detailed examples**, read [references/examples.md](references/examples.md)

## When to check

<rule>
**Diagnose before explaining.** When something doesn't work, check your state first.
</rule>

<rule>
**Check budget before complex tasks.** Know your limits before committing.
</rule>

<rule>
**Recall across turns.** Store preferences in your scratchpad, read them back later.
</rule>

## When to set

<rule>
**Only set when benefit is clear and user is informed.** Warn before changing model.
</rule>

| Situation | Command |
|-----------|---------|
| Check capacity for a large task | `my(action="check", key="context_window_tokens")` |
| Switch model or context capacity | `my(action="set", key="model_preset", value="<preset-name>")` |
| Long multi-step task | `my(action="set", key="max_iterations", value=80)` |

**Tradeoff:** Bias toward stability. Only set when defaults are genuinely insufficient.

## Anti-patterns

<rule>
**Don't check every turn.** Costs a tool call. Use when you need information, not reflexively.
</rule>

<rule>
**Don't store sensitive data.** No API keys, passwords, or tokens in scratchpad.
</rule>

<rule>
**Don't set workspace.** Does not update file tool boundaries — won't work.
</rule>

## Constraints

- `model_preset` is saved for the current session; other modifications are in-memory only
- Scratchpad values survive across turns until the agent runtime restarts and are shared by its sessions; do not treat them as private per-session storage.
- Use `my(action="check", key="workspace_sandbox")` for the current project and file restriction. `workspace` is only a legacy agent-directory display.
- Direct `model` and `context_window_tokens` writes are rejected during active sessions because they would change the shared instance default. Use a configured `model_preset` instead.
- Protected params have type/range validation: `max_iterations` (1–100), `context_window_tokens` (4096–1M), `model` (non-empty str)
- If `tools.my.allow_set` is false, check only

## Related tools

| Need | Use | Persists? |
|------|-----|-----------|
| Temporary runtime notes | `my(action="set", key="...", value=...)` | Across turns, not restarts |
| Long-term facts | Memory skill (`MEMORY.md`, `USER.md`) | Yes |
| Permanent config change | Edit config file | Yes |

**Rule of thumb:** Durable facts? Memory. Temporary runtime notes? My.
