---
name: scroll-image-sequence
description: "1 skill'lik paket (Scroll tabanlı kare dizisi (canvas, scroll pozisyonu)). İlgili alt skill'in dosyasını oku ve uygula."
---

# scroll-image-sequence

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| scroll-image-sequence | Build a scroll-driven frame sequence (canvas frames tied to scroll position). Use for scroll-image-sequence, Apple-style frame-by-frame scroll heroes, or scrubb | `skills/scroll-image-sequence/TALIMAT.md` |
