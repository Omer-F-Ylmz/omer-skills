---
name: tasarim-katalog
description: "1 skill'lik paket (AI-slop olmayan tasarım referans kataloğu). İlgili alt skill'in dosyasını oku ve uygula."
---

# tasarim-katalog

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| tasarim-katalog | Use when picking a visual direction, reference site, UI library, font or design prompt source for a web page and you want proven, non-generic (non AI-slop) opti | `skills/tasarim-katalog/TALIMAT.md` |
