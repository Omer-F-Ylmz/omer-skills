---
name: departman-frontend
description: "1 skill'lik paket (Frontend/UI müdürü: tasarım yığını, sahne/animasyon, a11y-performans kapısı). İlgili alt skill'in dosyasını oku ve uygula."
---

# departman-frontend

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| departman-frontend | Frontend/UI müdürü: hangi tasarım aracı hangi sırayla. Arayüz, landing, bileşen, CSS/Tailwind/Razor işine başlarken önce oku. | `skills/departman-frontend/TALIMAT.md` |
