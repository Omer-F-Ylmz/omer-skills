---
name: fable-dusunme
description: "1 skill'lik paket (Zor işlerde düşünme yöntemi: çerçevele, alternatif, seçim, öz-eleştiri, doğrulama). İlgili alt skill'in dosyasını oku ve uygula."
---

# fable-dusunme

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| fable-dusunme | Zor işlerde (mimari, tasarım yönü, inatçı hata, çok seçenekli karar) düşünme yöntemi — çerçevele, 2-3 alternatif, gerekçeli seçim, öz-eleştiri, doğrulama. Kolay | `skills/fable-dusunme/TALIMAT.md` |
