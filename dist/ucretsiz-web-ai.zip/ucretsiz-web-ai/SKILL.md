---
name: ucretsiz-web-ai
description: "1 skill'lik paket (Girişsiz web AI araçları: Wan i2v, upscaler, ToolFK editör). İlgili alt skill'in dosyasını oku ve uygula."
---

# ucretsiz-web-ai

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| ucretsiz-web-ai | Girişsiz/ücretsiz web AI araçları (ToolFK + gömülü HF Space'ler): görsel→video (Wan 2.2), upscaler, prompt'lu görsel düzenleme (arka plan sil, nesne sil, 2D→3D, | `skills/ucretsiz-web-ai/TALIMAT.md` |
