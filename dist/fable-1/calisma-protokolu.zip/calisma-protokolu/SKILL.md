---
name: calisma-protokolu
description: "1 skill'lik paket (Fable 5.1 davranışından damıtılmış çalışma protokolü). İlgili alt skill'in dosyasını oku ve uygula."
---

# calisma-protokolu

Bu paket 1 skill'i tek girişte toplar (claude.ai skill sınırı ve jeton tasarrufu). Kullanım: aşağıdan işe uyan alt skill'i seç, dosyasını oku, talimatını uygula. Birden çok alt skill gerekebilir.

> Not: claude.ai bir pakette yalnız tek SKILL.md kabul ettiği için alt skill'lerin talimat dosyası `skills/<ad>/TALIMAT.md` adını taşır (içerik orijinal SKILL.md ile aynı). Alt skill içinde "SKILL.md" geçen yerler kendi TALIMAT.md'sini kasteder.

| skill | ne zaman | dosya |
|---|---|---|
| calisma-protokolu | Work protocol distilled from Fable 5.1's visible behavior — goal first, cheapest discovery, small verified steps, short evidence-backed output. Use for any codi | `skills/calisma-protokolu/TALIMAT.md` |
